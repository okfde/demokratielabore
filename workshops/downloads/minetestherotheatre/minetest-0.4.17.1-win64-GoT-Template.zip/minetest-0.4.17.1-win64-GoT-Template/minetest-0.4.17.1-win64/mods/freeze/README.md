Minetest freeze
===============
Minest mod for freezing players

Commands:
---------
`/freeze <playername>`  
With this command you can freeze a player.  
`/unfreeze <playername>`  
This command is for unfreezing a player.  

License:
--------
See LICENSE.txt