﻿
Decorative Computers Mod for Minetest
by Diego Martínez <kaeza@users.sf.net>

How to install:
Unzip the archive an place it in minetest-base-directory/mods/minetest/
if you have a windows client or a linux run-in-place client. If you have
a linux system-wide instalation place it in ~/.minetest/mods/minetest/.
If you want to install this mod only in one world create the folder
worldmods/ in your worlddirectory.
For further information or help see:
http://wiki.minetest.com/wiki/Installing_Mods

How to use the mod:
For now just use creative mode or the `/give' or `/giveme' chat commands
 to get the items.

These are the items currently defined by this mod:

computer:printer (printer scanner combo)
computer:server (rack server)
computer:tower (modern type)
computer:monitor (LCD with keyboard)
computer:router (wifi type)
computer:babytower
computer:shefriendSOO
computer:slaystation
computer:vanio
computer:spectre
computer:slaystation2
computer:admiral64
computer:admiral128

There's also a `computer:computer' alias to `computer:babytower'.

License:
Sourcecode: WTFPL (see below)
Graphics: WTFPL (see below)

Thanks to all the people in the forums and the #minetest IRC channel for
 their support and suggestions; in no particular order:
  OldCoder, Josh, tonyka, VanessaE, davidpace, Jordach, and all the other
  sirs/madammes that I forgot to mention (sorry, please remind me if it
  was you ;) ). 

See also:
http://minetest.net/

         DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2012 Diego Martínez <lkaezadl3@gmail.com>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO. 
