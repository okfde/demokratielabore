ts_furniture
============

This mod adds basic furniture (Chairs, Tables, Small Tables, Tiny Tables, Benches).
It was made by Thomas-S.
It is published under the CC0 license.
